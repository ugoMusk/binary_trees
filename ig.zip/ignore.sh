#!/usr/bin/env bash

file=".gitignore";
mainfiles="$(ls | grep main.c)";
exec=$(find . \! -regex '.*/.*/.*' -executable -type f | sed -e 's%^\./%%');

for bin in $exec;do grep -xqF -- "$bin" "$file" || echo "$bin"  >> "$file";done
	   
for mfile in $mainfiles;do grep -xqF -- "$mfile" "$file" || echo "$mfile" >> "$file";done
